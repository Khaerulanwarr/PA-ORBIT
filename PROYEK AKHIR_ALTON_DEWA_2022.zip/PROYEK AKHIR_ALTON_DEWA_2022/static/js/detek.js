let video = document.getElementById("video");
let canvas = document.body.appendChild(document.createElement("canvas"));
let ctx = canvas.getContext("2d");
let displaySize;

let width = 1200;
let height = 720;

    const startSteam = () => {
        console.log("startstream")
        navigator.mediaDevices.getUserMedia({
            video: {width, height},
            audio : false
        }).then((steam) => {video.srcObject = steam});
    }
    
    Promise.all([
        faceapi.nets.ageGenderNet.loadFromUri('../static/js/models'),
        faceapi.nets.ssdMobilenetv1.loadFromUri('../static/js/models'),
        faceapi.nets.tinyFaceDetector.loadFromUri('../static/js/models'),
        faceapi.nets.faceLandmark68Net.loadFromUri('../static/js/models'),
        faceapi.nets.faceRecognitionNet.loadFromUri('../static/js/models'),
        faceapi.nets.faceExpressionNet.loadFromUri('../static/js/models')
    ]).then(startSteam);
    
    async function detect() {
        const detections = await faceapi.detectAllFaces(video)
                                    .withFaceLandmarks()
                                    .withFaceExpressions()
                                    .withAgeAndGender();
        //console.log(detections);
        
        ctx.clearRect(0,0, width, height);
        const resizedDetections = faceapi.resizeResults(detections, displaySize)
        faceapi.draw.drawDetections(canvas, resizedDetections);
        faceapi.draw.drawFaceLandmarks(canvas, resizedDetections);
        faceapi.draw.drawFaceExpressions(canvas, resizedDetections);
    
        console.log(resizedDetections);
        resizedDetections.forEach(result => {
            const {age, gender, genderProbability} = result;
            new faceapi.draw.DrawTextField ([
                `${Math.round(age,0)} Tahun`,
                `${gender} ${Math.round(genderProbability)}`
            ],
            result.detection.box.bottomRight
            ).draw(canvas);
        });
    }
    
    video.addEventListener('play', ()=> {
        displaySize = {width, height};
        faceapi.matchDimensions(canvas, displaySize);
    
        setInterval(detect, 100);
    })


